﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica3
{
    public class Program
    {
        private List<Usuario> listaUsuarios = new List<Usuario>();
        static void Main(string[] args)
        {
            
            string opcion;
            do
            {
                Console.WriteLine("-------------------------");
                Console.WriteLine("Menú principal");
                Console.WriteLine("-------------------------");
                Console.WriteLine("1.-Login");
                Console.WriteLine("2.-Registrar");
                Console.WriteLine("3.-Salir");

                Console.WriteLine("Introduce una opción: ");
                opcion = Console.ReadLine(); //Dentro de la cadena de caracteres cojo solo el primer elemento

                switch (opcion[0])
                {
                    case '1':

                }

            } while (opcion[0] != '3');
            Console.WriteLine("Programa terminado");
            Console.ReadLine();
        }
        public void AgregarUsuario(string nombreyapellidos, string contraseña, string usuario )
        {
            Usuario nuevo = new Usuario( nombreyapellidos,contraseña, usuario);
            listaUsuarios.Add(nuevo);

        }
    }
}
