﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practica3
{
    public class Usuario
    {
        //Atributos
        private string usuario;
        private string nombreyapellidos;
        private string contrasena;

        public Usuario(string nombreyapellidos, string contrasena,string usuario)
        {
            this.nombreyapellidos = nombreyapellidos;
            this.contrasena = contrasena;
            this.usuario = usuario;
        }
        
        //Accesores y mutadores
        public void SetNombre(string nombre)
        {
            this.nombreyapellidos = nombre;
        }
        public string GetNombre()
        {
            return this.nombreyapellidos;
        }
        public void SetContrasena(string contrasena)
        {
            this.contrasena = contrasena;
        }
        public string GetContrasena()
        {
            return this.contrasena;
        }
        public void SetUsuario(string usuario)
        {
            this.usuario = usuario;
        }
        public string GetUsuario()
        {
            return this.usuario;
        }


    }
}
